Python Disassembler and Simulator (AKA Project 2, CS3339)
Instructor: Greg LaKomski

Students:
Mcg76 - Michael Griffith
E_k79 - Erik Krakar



The file will use the command line for the input and output files (Disassembler will have _dis.txt and Simulator will have _sim.txt)
Then, after moving all relevant files (you only need the team10_project2.py, Diassembler.py, and the input/bin file) into the same directory:

1. Put team10_project2.py -i "<dis_inputfilename here>" -o "<dis_outputfilename here>" in the command line
2. Run the program
